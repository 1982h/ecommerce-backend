const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const productroutes = require('./routes/productroutes');
const cartroutes = require('./routes/cartroutes');
const connectDB = require("./config/db");
const errorHandler = require("./middleware/errorhandler");

dotenv.config();

connectDB();

app = errorHandler;

const app = express();

app.use(cors());

app.use(express.json());

app.get("/", (req, res) => {
    res.send("E-Commerce API Running...");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});